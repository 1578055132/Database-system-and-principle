## 第四章——关系数据库标准语言SQL

### SQL简介

#### SQL语言按功能划分为四部分

>- 数据定义——定义表、视图和索引
>- 数据操纵——查询、插入、删除和修改
>- 数据控制——访问权限管理、事务管理
>- 嵌入式SQL——SQL语句嵌入到程序语言中使用

#### SQL的动词

| SQL 功 能 | 动词                   |
| --------- | ---------------------- |
| 数据查询  | SELECT                 |
| 数据定义  | CREATE，DROP，ALTER    |
| 数据操纵  | INSERT，UPDATE，DELETE |
| 数据控制  | GRANT,REVOKE           |

### SQL的系统结构

<img src="https://tvax3.sinaimg.cn/large/007YIYRqly1h2x5q1fjfgj30sk0gzwiz.jpg" alt="image-20220603203512394" style="zoom:50%;" />

>- SQL的表分为两种：基本表和视图
>
>- 基本表（base table,table）
>  - 独立存在的表
>  - 一个关系模式对应一个基本表
>- 视图(view)
>  - 是从一个或多个基本表中导出的表，仅有逻辑上的定义，不实际存储数据，是一种虚表。
>  - 视图的定义存储在数据字典中，在使用的时候，根据定义从基本表中导出数据供用户使用。
>  - 视图可以象基本表一样进行查询和某些更新操作。

### SQL的数据定义

<img src="https://tva3.sinaimg.cn/large/007YIYRqly1h2x5q1ovmyj30u909jgs2.jpg" alt="image-20220603223657384" style="zoom:50%;" />

#### SQL模式的定义

>CREATE SCHEMA ＜模式名＞ AUTHORIZATION ＜用户名＞
>
>［＜表定义子句＞｜＜视图定义子句＞｜＜授权定义子句＞］;

~~~sql
/*(模式名可缺省)例——*/
CREATE SCHEMA AUTHORIZATION ross
CREATE TABLE t1 (c1 INT PRIMARY KEY,
				c2 INT REFERENCES t2(c1))
CREATE TABLE t2 (c1 INT PRIMARY KEY,
				c2 INT REFERENCES t1(c1));
~~~

##### SQL模式的删除

>DROP SCHEMA〈模式名〉［CASCADE│RESTRICT］

##### 定义基本表

>CREATE TABLE <表名>
>
>(<列名> <数据类型>[ <列级完整性约束条件> ]
>
>[, <列名> <数据类型>[ <列级完整性约束条件> ] ]
>
>...
>
>[,<表级完整性约束条件>]);
>
>◼ <表名>：所要定义的基本表的名字
>
>◼ <列名>：组成该表的各个属性（列）
>
>◼ <列级完整性约束条件>：涉及相应属性列的完整性约束条件
>
>◼ <表级完整性约束条件>：涉及一个或多个属性列的完整性约束条件

```sql
CREATE TABLE Student
( Sno CHAR(6) NOT NULL UNIQUE,
Sname CHAR(8),
Sage INT,
Ssex CHAR(2),
Sdept CHAR(12),
CONSTRAINT C1 CHECK (Ssex IN('男','女')),
CONSTRAINT S_PK PRIMARY KEY (Sno));
```

##### 修改基本表

>ALTER TABLE <表名>
>
>[ADD <列名> <数据类型> [<完整性约束>]]
>
>[DROP <列名> [CASCADE | RESTRICT]]
>
>[ALTER <列名> <数据类型> ];
>
>◼ ADD子句用于增加新列，包括列名、数据类型和列级完整性约束
>
>◼ DROP子句用于删除指定的列名，
>
>◼ CASCADE表示删除列时自动删除引用该列的视图和约束
>
>◼ RECTRICT表示没有视图和约束引用时才能删除该列，否则将拒绝删除操作
>
>◼ ALTER子句用于修改列的定义，如修改列的数据类型或修改列的宽度等

##### 删除基本表

>DROP TABLE <表名> [RESTRICT|CASCADE];
>
>◼ 若选择RESTRICT，则删除的基本表不能被其他表的约束所引用（如CHECK，FOREIGN KEY等约束），不能有视图，不能有触发器，不能有存储过程或函数
>
>等。如果存在这些依赖该表的对象，则此表不能被删除。
>
>◼ 若选择CASCADE，则该表的删除没有限制条件。在删除基本表的同时，相关的依赖对象，例如视图等都将被一起删除。
>
>◼ 一般在缺省情况下默认为RESTRICT，与具体实现有关。

##### 建立索引

>CREATE [UNIQUE] [CLUSTER] INDEX <索引名> ON <表名> (<列名>[<次序>][,<列名>[<次序>] ]...)
>
>◼ <表名>指定要建索引的基本表名字
>
>◼ 索引可以建立在该表的一列或多列上，各列名之间用逗号分隔
>
>◼ <次序>指定索引值的排列次序，升序ASC，降序DESC。缺省值：ASC
>
>◼ UNIQUE表明此索引的每一个索引值只对应唯一的数据记录
>
>◼ CLUSTER表示要建立的索引是聚集索引（ClusterIndex）

##### 删除索引

>DROP INDEX <索引名>；
>
>◼ 删除索引时，系统会从数据字典中删去有关该索引的描述。
>
>◼ 例：
>
>删除学生表上建立的SSNO索引。
>
>DROP INDEX S_SNO;

### SQL数据查询

#### 查询语句一般格式

>SELECT [ALL|DISTINCT] <目标列表达式> [,<目标列表达式>] ...
>
>FROM <表名或视图名>[, <表名或视图名> ] ...
>
>[ WHERE <条件表达式1> ]
>
>[ GROUP BY <列名1> [ HAVING <条件表达式2> ] ]
>
>[ ORDER BY <列名2> [ ASC|DESC ] ]；
>
>◼ SELECT子句：指定要显示的属性列
>
>◼ FROM子句：指定查询对象(基本表或视图)
>
>◼ WHERE子句：指定查询条件
>
>◼ GROUP BY子句：对查询结果按指定列的值分组，该属性列值相等的元组为一个组。通常会在每组中使用聚集函数。
>
>◼ HAVING短语：筛选出满足指定条件的组
>
>◼ ORDER BY子句：对查询结果表按指定列值的升序或降序排序
>
>◼ DISTINCT表示去掉重复元组，ALL则容许重复元组

#### WHERE子句常用的查询条件

| 比较表达式 | <列名1> 比较算符 <列名2（或常量)>比较算符：=、>、>=、<、<=、<>（或!=） |
| ---------- | ------------------------------------------------------------ |
| 逻辑表达式 | <条件表达式1> 逻辑算符 <条件表达式2>逻辑算符：AND、OR、NOT   |
| BETWEEN    | <列名1> （NOT）BETWEEN <常量1或列名2>AND <常量2或列名3>      |
| IN         | <列名>（NOT）IN （常量表列 或 SELECT语句）                   |
| LIKE       | <列名>（NOT）LIKE ‘匹配字符串’匹配符：“_”表示匹配一个字符，“%”表示匹配任意字符串 |
| NULL       | <列名> IS（NOT） NULL                                        |
| EXISTS     | （NOT）EXISTS （SELECT语句）                                 |

#### ESCAPE 短语

```sql
SELECT * FROM student t where t.name like '%/%' escape '/'
```

>escape '/' 是指用'/'说明在/后面的字符不是通配符，而是普通符。

#### 涉及空值的查询

>使用谓词 IS NULL 或 IS NOT NULL

#### 使用聚集函数

>##### SQL提供了许多聚集函数，用来实现统计查询
>
>- 计数
>
>  - COUNT([DISTINCT|ALL] *)
>  - COUNT([DISTINCT|ALL] <列名>)
>
>- 计算总和 SUM ([DISTINCT|ALL] <列名> )
>
>- 计算平均值 AVG ([DISTINCT|ALL] <列名> )
>
>- 求最大值 MAX ([DISTINCT|ALL] <列名> )
>
>- 求最小值 MIN ([DISTINCT|ALL] <列名> )
>
>  选项DISTINCT表示在计算时要取消指定列中的重复值；ALL表示不取消重复值；默认为ALL。

#### 对查询结果分组

>##### 使用GROUP BY子句分组
>
>##### 细化聚集函数的作用对象
>
>- 未对查询结果分组，聚集函数将作用于整个查询结果
>- 对查询结果分组后，聚集函数将分别作用于每个组
>
>##### 分组方法
>
>- 按指定的一列或多列值分组，值相等的为一组
>
>##### 使用GROUP BY子句后，SELECT子句的列名列,表中只能出现分组属性和聚集函数
>
>##### GROUP BY子句的作用对象是查询的中间结果表
>
>##### 使用HAVING短语筛选最终输出结果
>
>- 只有满足HAVING短语指定条件的组才输出

#### HAVING短语与WHERE子句的区别

>##### 作用对象不同
>
>- WHERE子句作用于基表或视图，从中选择满足条件的元组(tuple)。
>- HAVING 短 语 作 用 于 组 ， 从 中 选 择 满 足 条 件 的 组(group)。
>
>##### WHERE子句中不能使用聚集函数；而HAVING短语中可以使用聚集函数

#### SQL中连接查询的主要类型

>- 广义笛卡尔积
>
>- 等值(含自然连接)
>- 非等值连接查询
>- 自身连接查询
>- 外连接查询
>- 复合条件连接查询

#### 广义笛卡尔积

```sql
SELECT Student.* , SC.*
FROM Student, SC
```

#### 等值连接

```sql
/*【例】查询每个学生及其选修课程的情况。*/
SELECT Student.* , SC.*
FROM Student , SC
WHERE Student.Sno = SC.Sno
```

#### 自然连接

```sql
SELECT *
FROM Student NATURAL JOIN SC；
```

#### 自身连接

```sql
/*【例】查询每一门课的间接先修课(即先修课的先修课)*/
SELECT FIRST.Cno，SECOND.Cpno
FROM Course AS FIRST，Course AS SECOND
WHERE FIRST.Cpno = SECOND.Cno；
```

#### 内连接

>◼ 典型的连接运算，使用像 = 或 <> 之类的比较运算符）
>
>◼ 包括相等连接和自然连接
>
>◼ 内连接使用比较运算符根据每个表共有的列的值匹配两个表中的行

```sql
SELECT buyer_name, sales.buyer_id, qty
FROM buyers INNER JOIN sales
ON buyers.buyer_id = sales.buyer_id
```

#### 外连接

>##### 外连接与普通连接的区别
>
>- 普通连接操作只输出满足连接条件的元组
>- 外连接操作以指定表为连接主体，将主体表中不满足连接条件的元组一并输出
>
>##### 外连接分类
>
>- 左外连接(LEFT OUTER JOIN)
>- 右外连接(RIGHT OUTER JOIN)
>- 全外连接(FULL OUTER JOIN)

```sql
/*【例】查询每个学生的选课情况，包括没有选课的学生*/
SELECT Student.Sno, Sname, Ssex, Sage, Sdept,
Cno, Grade
FROM Student LEFT OUTER JOIN SC
ON (Student.Sno = SC.Sno)
```

#### 复合条件连接

```sql
/*【例】查询选修2号课程且成绩在90分以上的所有*/
学生的 学号、姓名
SELECT Student.Sno, Student.Sname
FROM Student, SC
WHERE Student.Sno = SC.Sno AND
SC.Cno= ‘ 2 ’ AND
SC.Grade > 90;
```

#### 嵌套查询概述

>◼ 一个SELECT-FROM-WHERE语句称为一个查询块
>
>◼ 将一个查询块嵌套在另一个查询块的WHERE子句或HAVING短语的条件中的查询称为嵌套查询

```sql
/*【例】查询选修了 “信息系统”课程的学生的学号*/
和姓名
SELECT Sno, Sname
FROM Student
WHERE Sno IN
(SELECT Sno
FROM SC
WHERE Cno IN
(SELECT Cno
FROM Course
WHERE Cname= ‘信息系统’))
```

#### 带有ANY或ALL谓词的子查询

>- 谓词语义
>  - ANY 任意一个值
> 
>  - ALL 所有值
> 
>- 配合比较运算符使用
>  - \> ANY 大于子查询结果中的某个值
>   - \> ALL 大于子查询结果中的所有值
>   - < ANY 小于子查询结果中的某个值
>   - < ALL 小于子查询结果中的所有值
>   - \>= ANY 大于等于子查询结果中的某个值
>   - \>= ALL 大于等于子查询结果中的所有值
>   - <= ANY 小于等于子查询结果中的某个值
>   - <= ALL 小于等于子查询结果中的所有值
>   - = ANY 等于子查询结果中的某个值
>   - =ALL 等于子查询结果中的所有值（通常没有实际意义）
>   - !=（或<>）ANY 不等于子查询结果中的某个值
>   - !=（或<>）ALL 不等于子查询结果中的任何一个值

```sql
/*【例】查询其他系中比CS系任意一个学生年龄小的学生姓名和年龄*/
用ANY谓词实现——
SELECT Sname, Sage
FROM Student
WHERE Sage < ANY (
SELECT Sage
FROM Student
WHERE Sdept= 'CS')
AND Sdept <> 'CS' ;
/*用聚集函数实现——*/
SELECT Sname, Sage
FROM Student
WHERE Sage < (
SELECT MAX(Sage)
FROM Student
WHERE Sdept= 'CS')
AND Sdept <> 'CS' 
```

#### 带有EXISTS谓词的子查询

>1. EXISTS谓词
>
>    ◼ 带有EXISTS谓词的子查询不返回任何数据，只产生逻辑真值“true”或逻辑假值“false”。
>
>    ◼ 若内层查询结果非空，则返回真值
>
>    ◼ 若内层查询结果为空，则返回假值
>
>    ◼ 由EXISTS引出的子查询，其目标列表达式通常用* ,因为带EXISTS的子查询只返回真值或假值，给出列名无实际意义
>
>2. NOT EXISTS谓词

```sql
/*【例】查询没有选修1号课程的学生姓名。*/
SELECT Sname
FROM Student
WHERE NOT EXISTS
( SELECT *
FROM SC
WHERE Sno = Student.Sno
AND Cno='1')；
```

#### 集合查询

>- 标准SQL直接支持的集合操作种类
>  - 并操作(UNION)
>
>- 一般商用数据库支持的集合操作种类
>
>  - 并(UNION)
>
>  - 交(INTERSECT)
>
>  - 差(MINUS，EXCEPT)

```sql
/*【例】查询计算机系的学生或者年龄不大于19岁的学生。*/
SELECT *
FROM Student
WHERE Sdept= 'CS'
UNION
SELECT *
FROM Student
WHERE Sage<=19
```

```sql
/*【例】查询计算机系的学生与年龄不大于19岁的学生的交集。*/
(SELECT *
FROM Student
WHERE Sdept='CS')
INTERSECT
(SELECT *
FROM Student
WHERE Sage<=19)
/*标准SQL中没有提供集合交操作，但可用其他方法间接实现。*/
SELECT DISTINCT *
FROM Student
WHERE Sdept= 'CS'
AND Sage<=19
```

```sql
/*【例】查询学生姓名与教师姓名的差集。实际上是查询学校中未与教师同名的学生姓名。*/
SELECT Sname
FROM Student
EXCEPT
SELECT Tname
FROM Teacher;
/*标准SQL中没有提供集合差操作，但可用其他方法间接实现。*/
SELECT DISTINCT Sname
FROM Student
WHERE Sname NOT IN
(SELECT Tname
FROM Teacher);
```

### SQL数据更新

#### 数据更新

>◼ 插入
>
>◼ 修改
>
>◼ 删除

#### 插入数据

>- 两种插入数据方式
>
> - 插入单个元组
> - 插入子查询结果
> - 插入单个元组
>
>- 语句格式
>
> INSERT INTO <表名> [(<属性列1>[,<属性列2 >...)]
>
> VALUES (<常量1> [，<常量2>] ... );
>
>- 功能: 将新元组插入指定表中。
>
>- INTO子句
> - 指定要插入数据的表名及属性列
> - 属性列的顺序可以与表定义中的顺序不一致
> - 没有指定属性列：表示要插入的是一条完整的元组，且属性列属性与表定义中的顺序一致
> - 指定部分属性列：插入的元组在其余属性列上取空值
>- VALUES子句
> - 提供的值必须与INTO子句匹配：个数、顺序和值的类型

```sql
/*【例】在学生表中插入一个学生元组，其学号为
101215，姓名为李斌，男，19岁，是计算机系
的学生。*/
INSERT INTO Student
VALUES(‘101215’,‘李斌’ ,‘男’ ,19, ‘计算机’);

INSERT INTO Student ( Sno, Sname, Sdept, Sage, Ssex )
VALUES(‘101215’,‘李斌’, ‘计算机’ ,19,‘男’);
```

#### 将子查询结果插入指定表中

>INSERT INTO <表名>[(<列名1>[,<列名2>, ])]
>
><SELECT语句>; /*子查询*/；

````sql
/*【例】计算计算机系每个学生的平均成绩，并保存在CS-AVG表中。*/
/*生成学生的平均成绩表CS-AVG*/
CREATE TABLE CS-AVG
(Sno CHAR(6)NOT NULL，
Grade NUMBER(4,1));
/*在CS-AVG中插入计算机系学生的平均成绩*/
INSERT INTO CS-AVG (Sno, Grade)
SELECT Sno, AVG(Grade) FROM SC
WHERE Sno IN (
SELECT Sno FROM Student
WHERE Sdept=‘CS’)
GROUP BY Sno ;
````

#### 修改数据

>UPDATE <表名>
>
>SET 列名1=<表达式1>[,列名2=<表达式2>]…
>
>[WHERE <条件表达式>];

```sql
/*【例】将数据库课的学分修改为4。*/
UPDATE Course SET Ccredit =4 WHERE Cname=’数据库’;
/*【例】将所有学生的年龄增加1岁。*/
UPDATE Student SET Sage=Sage+1;
/*【例】将所有选修了数据库课的学生的成绩清空。*/
UPDATE SC SET Grade=NULL
WHERE Cno IN
(SELECT Cno
FROM Course
WHERE Cname=‘数据库’);
```

#### 删除数据

>DELETE FROM <表名>
>[WHERE <条件>]；

```sql
/*◼ 删除一个或多个元组*/
/*【例】删除学号为201225的学生记录。*/
DELETE FROM Student WHERE Sno=’201225’;
/*【例】删除所有的学生选课记录。*/
DELETE FROM SC；
/*◼ 带子查询的删除*/
/*【例】删除所有选修数据库课学生的选课信息*/
DELETE FROM SC
WHERE Cno IN
(SELECT Cno FROM Course
WHERE Cname=‘数据库’);
```

#### 截断表TRUNCATE TABLE

>- 语句格式
>
>  TRUNCATE TABLE table_name
>
>- 功能
>
>  - 删除表中所有行（与不带 WHERE 子句的 DELETE 语句相同），但不记录单个行删除操作
>  - 比 DELETE 速度快，使用的系统和事务日志资源少
>    - DELETE 语句每次删除一行，并在事务日志中为所删除的每行记录一项。
>    - TRUNCATE TABLE 通过释放存储表数据所用的数据页来删除数据，并且只在事务日志中记录页的释放。
>
>- 操作不能回滚， 但DELETE 可以回滚

### SQL中的视图

#### 视图

>◼ 相对于基本表而言；**对应于外模式**
>
>◼ 是从一个或几个基本表（或视图）导出的**虚表**
>
>◼ 视图的定义是递归的，可以定义基于该视图的新视图
>
>◼ DBMS只存放视图的定义，**不存放视图的数据，不会出现数据冗余**
>
>◼ 基表中的数据发生变化，从视图中查询出的数据也改变
>
>◼ 视图实际上提供了一种观察数据的逻辑窗口，用户可从不同的角度观察数据库
>
>◼ 对视图的操作意味着对基表进行相对应的操作；但对视图的更新(插入数据、删除、修改)有一些限制

#### 创建视图

>◼ 语句格式
>
>CREATE VIEW <视图名> [(<列名1> [,<列名2>]...)]
>
>AS < SELECT语句>
>
>[WITH CHECK OPTION]；
>
>◼ DBMS执行CREATE VIEW语句时只是把视图的定义存入数据字典，并不执行其中的SELECT语句。在对视图进行操作时才按照视图定义生成数据，供用户使
>
>用。
>
>◼ SELECT语句表示子查询，视图的属性列和数据都是由该子查询决定的。
>
>◼ 选项[(<列名1>[, <列名2>])]用来定义视图的列名。
>
>◼ 组成视图的属性列名可以全部省略或全部指定
>
>◼ 省略:由SELECT查询结果的目标列名组成
>
>◼ 以下情况必须明确指定视图的所有列名:
>
>(1) 目标列中包含聚集函数或表达式
>
>(2) 视图中包含出现在多个表中的相同列名
>
>(3) 需要在视图中为某个列启用新的更合适的名字
>
>◼ WITH CHECK OPTION选项的作用
>
>(1) 通过视图插入、删除或修改元组时，检查元组是否满足视图定义中的条件（即子查询中的条件表达式），如果不满足将拒绝执行这些操作。
>
>(2) 如果视图定义中含有条件，建议选择WITH CHECKOPTION选项，以约束更新的数据

```sql
/*【例】建立年龄小于23岁的学生视图，并要求数据更新时进行检查。*/
CREATE VIEW Sage_23
AS SELECT * FROM Student
WHERE Sage < 23
WITH CHECK OPTION;
```

#### 删除视图

>◼ DROP VIEW <视图名> ；
>
>(1) 该语句从数据字典中删除指定的视图定义
>
>(2) 删除基表时，由该基表导出的所有视图定义都必须显式删除。

```sql
【例】删除学生视图CS_90。*/
DROP VIEW CS_90;
```

#### 视图更新

>◼ 对视图的数据插入、删除、修改最终转换为对基表的操作来进行
>
>◼ 用户角度：更新视图与更新基本表相同
>
>◼ 指定WITH CHECK OPTION子句后，DBMS在更新视图时会进行检查，防止用户通过视图对不属于视图范围内的基本表数据进行更新
>
>◼ 有些视图是不可更新的——因为对这些视图的更新不能唯一地有意义地转换成对相应基本表的更新。

#### 视图的作用

>- **视图提供了数据的逻辑独立性**
>  - 数据库的逻辑结构发生改变时，由于数据库的数据不变，可以通过对视图的重新定义，使用户的外模式保持不变，从而使查询视图数据的应用程序不必修改。
>  - 视图在一定程度上保证了数据的逻辑独立性
>  - 视图只能在一定程度上提供数据的逻辑独立性
>    - 视图更新是有条件的，视图的重新定义可能会影响到数据的更新，此时修改数据的应用程序可能也需要做相应的修改。
>
>- **简化了用户视图**
>  - 视图使用户把注意力集中在自己所关系的数据上，简化了用户的数据结构；
>  - 定义视图能够简化用户的操作；适当的利用视图可以更清晰的表达查询
>    - 基于多张表连接形成的视图
>    - 基于复杂嵌套查询的视图
>    - 含导出属性的视图
>
>- 视图使用户以不同角度看待相同的数
>  - 视图机制能使不同用户以不同方式看待同一数据，适应数据库共享的需要。
>- 视图提供了安全保护功能
>  - 对不同用户定义不同视图，使每个用户只能看到他有权看到的数据，实现对机密数据的保护。
>  - 可以通过WITH CHECK OPTION对关键数据定义操作限制，比如操作时间的限制。

```sql
/*【例】学生关系Student(Sno,Sname,Ssex,Sage,Sdept)， 垂直
分成两个基本表：SX(Sno,Sname,Sage)，SY(Sno,Ssex,Sdept)*/
CREATE VIEW Student(Sno,Sname,Ssex,Sage,Sdept)
AS
SELECT SX.Sno, SX.Sname, SY.Ssex, SX.Sage,
SY.Sdept
FROM SX,SY
WHERE SX.Sno=SY.Sno;
/*使用户外模式保持不变，用户应用程序通过视图仍然能够查找数据。*/
```

### SQL的数据控制

#### 授权

>◼ 授权：是指有授予权的用户将自己所拥有的权限授予其他用户。
>
>◼ 语句格式：
>
>GRANT <权限1>[,<权限2>]...
>
>[ON <对象类型> <对象名>]
>
>TO <用户1>[,<用户2>... |PUBLIC]
>
>[WITH GRANT OPTION];
>
>◼ 功能：把指定对象的某些权限授予指定的用户。
>
>◼ WITH GRANT OPTION短语表示被授权的用户，还可以把获得的权限再授予其它用户。
>
>◼ PUBLIC短语表示把权限授予数据库的所有用户

```sql
/*【例】授予用户User2在表Student上的查询权和删除权，同时使User2拥有将所得权限授予其他用户的权力。*/
GRANT SELECT, DELETE
ON TABLE Student
TO User2
WITH GRANT OPTION;
```

#### 权限回收

>- 具有授予权的用户可以通过回收语句将所授予的权限回收
>
>- 回收语句格式为：
>
>  REVOKE <权限1>[,<权限2>]...
>
>  [ON <对象类型> <对象名>]
>
>  FROM <用户1>[,<用户2> ...|PUBLIC]
>
>  [RESTRICT|CASCADE];
>
>  - CASCADE选项表示回收权限时要引起级联操作，要把转授出去的权限一起回收。
>
>  - RESTRICT选项表示，只有用户没有将拥有的权限转授给其他用户时才能回收该用户的权限，否则系统将拒绝执行

```sql
/*【例】回收用户User2对学生表Student的查询权和删除权。*/
REVOKE SELECT, DELETE
ON TABLE Student
FROM User2
CASCADE;
```

### 嵌入式SQL

#### 嵌入式SQL概述

>- 
>  SQL语言提供了两种不同的使用方式
>
>  - 交互式
>  - 嵌入式
>
>  SQL嵌入到C, C++, Java, COBOL等程序设计语言中，称为嵌入式SQL(Embedded SQL)。
>
>- 将SQL嵌入主语言后
>
>  - SQL语句负责数据库的操纵
>  - 宿主语言负责控制程序流程和数据的输入输

#### 嵌入式SQL与主语言的接口

>- 将SQL语句嵌入到宿主语言中必须解决的问题
>  - 将嵌入主语言的SQL语句编译成为可执行代码
>  - 数据库和主语言程序间的通信
>  - 数据库和主语言程序间的数据交换
>  - 需要协调面向集合和面向记录两种不同的处理方式

#### 不用游标的嵌入式SQL

>- 如果嵌入式SQL语句的执行结果为单记录，或一次处理多个记录而不是对记录逐个处理，可以不用游标。
>- 不用游标的SQL语句的种类
>  - 说明性语句
>  - 数据定义语句
>  - 查询结果为单记录的SELECT语句
>  - INSERT语句
>  - 非CURRENT形式的UPDATE语句
>  - 非CURRENT形式的DELETE语句
>  - 授权和回收语句

```sql
/*◼ 不用游标，用主变量；先说明，后使用。*/
【例】定义字符型主变量Sno和Sname。
EXEC SQL BEGIN DECLARE SECTION;
CHAR Sno(6);
CHAR Sname(8);
... ...
EXEC SQL END DECLARE SECTION；
/*◼ 所有主变量在使用前需用DECLARE语句说明。*/
```

```sql
/*【例】根据学号查询学生姓名和选修C2课的成绩*/
EXEC SQL SELECT Sname, Cno, Grade
INTO :Hsname, :Hcno, :Hgrade
FROM Student, SC
WHERE Student.Sno = :Hsno AND Cno=‘C2’
AND Student.sno=SC.sno;
/*◼ Hsno为输入主变量，在执行该语句前，应先用主语言命令给Hsno赋值*/
/*◼ INTO子句指定将查询结果放入相应的主变量（按顺序对应）*/
```

```sql
/*【例】在学生选课表中插入选课成绩。*/
EXEC SQL INSERT INTO SC
VALUES (:Sno, :Cno, :GRADE);
/*◼ 在执行该语句前，应先给主变量赋值，然后执行该语句，将选课成绩插入SC表。*/
```

#### 用游标的嵌入式SQL

>- 主语言一次只能处理一条记录，当处理的结果为多条记录时，需借助游标机制，把对结果集的操作转化为对单个记录的处理。
>- 必须使用游标的SQL语句
>  - 查询结果为多条记录的SELECT语句
>  - CURRENT形式的UPDATE语句
>  - CURRENT形式的DELETE语句
>- 使用游标的步骤
>  - 定义游标
>  - 打开游标
>  - 推动游标
>  - 关闭游标

#### 定义游标

>- 使用DECLARE语句
>- 语句格式
>  EXEC SQL DECLARE <游标名> CURSOR
>   FOR <SELECT 语句>
>   [FOR UPDATE OF <列名>];
>- 功能
>  - 说明性语句
>  - 用于建立游标和SELECT语句之间的关系，并不执行SELECT语句
>  - FOR UPDATE OF子句表示更新查询结果中的列

#### 打开游标

>- 使用OPEN语句
>
>- 语句格式
>
>  EXEC SQL OPEN <游标名>;
>
>- 功能
>
>  - 执行与游标关联的SQL查询语句，并将查询结果放入数据缓冲区。
>  - 此时游标处于打开状态，游标指针指向查询结果集中第一条记录之前的位置。

#### 推动游标

>- 使用FETCH语句
>
>- 语句格式
>
>  EXEC SQL FETCH <游标名>
>
>  INTO <主变量> [,<主变量>]...;
>
>- 功能
>
>  - 把游标向前推进一个位置，然后按照游标的当前位置取一条记录（元组），将元组的值赋给对应的主变量。
>  - 每执行一次该语句，游标向前推进一个位置。
>  - 如果最后游标指针所指的位置为空，则SQLCODE返回一个状态码，表示缓冲区没有可处理的元组

#### 关闭游标

>- 使用CLOSE语句
>
>- 语句格式
>
>  EXEC SQL CLOSE <游标名>;
>
>- 功能
>
>  - 关闭游标，释放结果集占用的缓冲区及其他资源
>
>- 说明
>
>  - 游标被关闭后，就不再和原来的查询结果集相联系
>  - 被关闭的游标可以再次被打开，与新的查询结果相联系

#### 静态SQL

>◼ 数据库对象、查询条件以及所做的操作，在预编译时都是确定的。
>
>◼ 语句中主变量的个数与数据类型在预编译时也是确定的。
>
>◼ 用户可以在程序运行过程中根据实际需要输入WHERE子句或HAVING子句中某些变量的值。
>
>◼ 只是主变量的值可以在程序运行过程中动态输入。
>
>◼ 静态SQL语句提供的编程灵活性在许多情况下仍显得不足，不能编写更为通用的程序。

#### 动态SQL

>- 在程序运行期间临时组装SQL语句
>- 动态SQL的应用范围
>  - 在预编译时下列信息不能确定时
>    - SQL语句正文
>    - 主变量个数
>    - 主变量的数据类型
>    - SQL语句中引用的数据库对象（列、索引、基本表、视图等）
